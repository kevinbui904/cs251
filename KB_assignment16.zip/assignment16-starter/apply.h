#ifndef _APPLY
#define _APPLY

Value *apply(Value *function, Value *args);

#endif
