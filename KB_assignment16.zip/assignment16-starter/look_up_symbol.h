#ifndef _LOOK_UP_SYMBOL
#define _LOOK_UP_SYMBOL

Value *look_up_symbol(Value *expr, Frame *frame);

#endif
