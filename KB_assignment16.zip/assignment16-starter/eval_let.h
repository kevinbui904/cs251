#ifndef _EVAL_LET
#define _EVAL_LET

Value *eval_let(Value *args, Frame *parent_frame);

#endif
