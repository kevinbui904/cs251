#ifndef _EVAL_QUOTE
#define _EVAL_QUOTE

Value *eval_quote(Value *args);

#endif
