#ifndef _EVAL_IF
#define _EVAL_IF

Value *eval_if(Value *args, Frame *parent_frame);

#endif
