#ifndef _EVAL_LAMBDA
#define _EVAL_LAMBDA

Value *eval_lambda(Value *args, Value *expr, Frame *active_frame);

#endif
