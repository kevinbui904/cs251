#ifndef _EVAL_DEFINE
#define _EVAL_DEFINE

Value *eval_define(Value *symbol, Value *value, Frame *active_frame);

#endif
